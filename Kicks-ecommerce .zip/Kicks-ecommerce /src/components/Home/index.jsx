
import { Link } from "react-router-dom";
import "./index.scss";


import React from "react";


const Home = () => {
  
  return (
    <div className="homebody">
    
    <h3> I am Victorious</h3>
     
    </div>
  );
};

export default Home;
